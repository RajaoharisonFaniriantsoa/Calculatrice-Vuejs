<template>
  <div id="app">
    <Calculatrice/>
    <Calculatrice0/>
  </div>
</template>

<script>
import Calculatrice from './components/Calculatrice.vue';
import Calculatrice0 from './components/Calculatrice0.vue';

export default {
  name: 'App',
  components: {
    Calculatrice,
    Calculatrice0,
  },
};
</script>
<style scoped>
   #app{
    display: flex;
   }
</style>



