<template>
  <div id="calculatrice">
    <div class="display">{{ display }}</div>
    <div class="buttons">
      <button v-for="button in buttons" :key="button" :class="buttonClass(button)" @click="pressButton(button)">{{ button }}</button>
    </div>
  </div>
</template>

<script>
import * as math from 'mathjs';

export default {
  data() {
    return {
      display: '',
      buttons: ['sin', 'cos', 'tan', 'del', 'AC', 'a/b', '√', '³√', '(', ')', 'log', 'ln', 'e', 'π', '!', '7', '8', '9', '+', '-', '4', '5', '6', 'x', ':', '1', '2', '3', '%', '^', '0', '.', '='],
      cubicRootNextNumber: false,
    };
  },
  methods: {
    pressButton(button) {
      if (button === '=') {
        try {
          this.display = this.display.replace(/x/g, '*');
          this.display = this.display.replace(/:/g, '/');
          this.display = this.display.replace(/log/g, 'log10');
          this.display = this.display.replace(/ln/g, 'log');
          this.display = this.display.replace(/e/g, '2.71828');
          this.display = this.display.replace(/π/g, '3.14159');
          this.display = this.display.replace(/√(\d+\.?\d*)/g, 'sqrt($1)');
          if (this.cubicRootNextNumber) {
            this.display = this.display.replace(/(\d+\.?\d*)$/, 'nthRoot($1, 3)');
            this.cubicRootNextNumber = false;
          }
          if (/log10[^()]*$/.test(this.display) || /log[^()]*$/.test(this.display) || /sin[^()]*$/.test(this.display) || /cos[^()]*$/.test(this.display) || /tan[^()]*$/.test(this.display)) {
            throw new Error;
          }
          this.display = String(math.evaluate(this.display));
        } catch (error){
            this.display = 'Syntax Error';
        }
      } else if (button === '³√') {
        this.cubicRootNextNumber = true;
      } else if (button === 'del') {
        this.display = this.display.slice(0, -1);
      } else if (button === 'AC') {
        this.display = '';
        this.cubicRootNextNumber = false;
      } else if (button === 'a/b') {
        try {
          if (this.display.includes('/')) {
            this.display = String(math.evaluate(this.display));
          } else {
            this.display = String(math.format(math.fraction(this.display), { fraction: 'ratio' }));
          }
        } catch (error){
            this.display = 'Syntax Error';
        }
      } else {
        this.display += button;
      }
    },
    buttonClass(button) {
      if (button === 'del') {
        return 'delButton';
      } else if (button === 'AC') {
        return 'acButton';
      } else if (button === '³√' && this.cubicRootNextNumber) {
        return 'activeButton';
      } else if (button === '=') {
        return 'equalsButton';
      } else {
        return '';
      }
    },
  },
};
</script>
