<template>
  <div id="calculatrice0">
    <div class="display0">{{ display }}</div>
    <div class="buttons">
      <button v-for="button in buttons" :key="button" :class="buttonClass(button)" @click="pressButton(button)">{{ button }}</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      display: '',
      buttons: ['7', '8', '9', 'del', 'AC', '4', '5', '6', '+', '-', '1', '2', '3', '*', '/', '0', '.', '%', '='], 
    };
  },
  methods: {
    pressButton(button) {
      if (button === '=') {
        try {
          this.display = this.display.replace(/x/g, '*');
          this.display = this.display.replace(/:/g, '/');
          this.display = String(eval(this.display));
        } catch (error){
            this.display = 'Syntax Error';
        }
      } else if (button === 'del') {
        this.display = this.display.slice(0, -1);
      } else if (button === 'AC') {
        this.display = '';
      } else {
        this.display += button;
      }
    },
    buttonClass(button) {
      if (button === 'del') {
        return 'delButton';
      } else if (button === 'AC') {
        return 'acButton';
      } else if (button === '=') {
        return 'equalsButton0';
      } else {
        return '';
      }
    },
  },
};
</script>
